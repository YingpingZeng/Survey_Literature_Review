
# Paper Comparison Table

| Paper            | Method            | Global Opt.? | Scenario                      |
|------------------|-------------------|--------------|-------------------------------|
| Govindu 2001     | Motion Matrix     | No           | Small-scale                   |
| Chatterjee 2013  | L1-IRLS           | Yes          | Robust rotation averaging     |
| Yang 2020        | SDP + Inlier Set  | Yes          | Point cloud under outliers    |
