
# Literature Map

- Rotation Averaging: Govindu 2001, Chatterjee 2013
- SDP Relaxation: Yang 2020
- Robust Estimation: Fredriksson 2016, Hartley 2011
