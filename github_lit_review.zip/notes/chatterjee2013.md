
# Chatterjee 2013 - Efficient and Robust Rotation Averaging

## Key Ideas
- Proposes L1-IRLS for robust rotation averaging.
- Handles outliers effectively.

## Method
- Iteratively reweighted least squares.
- Global optimum under certain conditions.

## Notes
- Useful for baseline comparisons.
