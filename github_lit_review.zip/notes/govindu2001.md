
# Govindu 2001 - Combining Two-View Constraints

## Key Ideas
- Combines multiple pairwise views using motion consistency matrix.
- SVD used to extract dominant direction.

## Notes
- Early foundational work.
